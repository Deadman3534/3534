﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main(string[] args)
    {
        // Declare an array with a minimum length of 20 elements
        int[] array = new int[20];

        // Fill the array with random numbers using a loop
        Random random = new Random(); // Create a new instance of the Random class
        for (int i = 0; i < array.Length; i++)
        {
            // Generate a random integer between 0 and 100
            array[i] = random.Next(0, 101);
        }

        // Print the unsorted array
        Console.WriteLine("Unsorted array:");
        foreach (int element in array)
        {
            Console.Write(element + " ");
        }
        Console.WriteLine();

        // Sort the array using the built-in Array.Sort method
        Array.Sort(array);

        // Print the sorted array
        Console.WriteLine("Sorted array:");
        foreach (int element in array)
        {
            Console.Write(element + " ");
        }
        Console.WriteLine();
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}
