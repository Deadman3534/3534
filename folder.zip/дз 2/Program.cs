﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Base class: Student 

/*
public class Student 
{
    public string LastName { get; set; }
    public string FirstName { get; set; }
    public int Age { get; set; }
    public string Major { get; set; }

    public Student(string lastName, string firstName, int age, string major)
    {
        LastName = lastName;
        FirstName = firstName;
        Age = age;
        Major = major;
    }
}

// Class: StudentDatabase
public class StudentDatabase
{
    private List<Student> students = new List<Student>();

    public void AddStudent(Student student)
    {
        students.Add(student);
    }

    public void RemoveStudent(Student student)
    {
        students.Remove(student);
    }

    public void PrintStudents()
    {
        foreach (Student student in students)
        {
            Console.WriteLine($"LastName: {student.LastName}, FirstName: {student.FirstName}, Age: {student.Age}, Major: {student.Major}");
        }
    }
}

// Main program class
class Program
{
    static void Main(string[] args)
    {
        StudentDatabase database = new StudentDatabase();

        // Add some students
        database.AddStudent(new Student("Ivanov", "Ivan", 20, "Computer Science"));
        database.AddStudent(new Student("Petrov", "Petr", 21, "Mathematics"));
        database.AddStudent(new Student("Sidorov", "Sidor", 22, "Physics"));

        // Print all students
        Console.WriteLine("All students:");
        database.PrintStudents();

        // Remove a student
        Student studentToRemove = new Student("Petrov", "Petr", 21, "Mathematics");
        database.RemoveStudent(studentToRemove);

        // Print all students again
        Console.WriteLine("Students after removal:");
        database.PrintStudents();

        // Wait for the user to press a key before closing the console window
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
} */


// Base class: Student
public class Student
{
    public string LastName { get; set; }
    public string FirstName { get; set; }
    public int Age { get; set; }
    public string Major { get; set; }

    public Student(string lastName, string firstName, int age, string major)
    {
        LastName = lastName;
        FirstName = firstName;
        Age = age;
        Major = major;
    }
}

// Class: StudentDatabase
public class StudentDatabase
{
    private List<Student> students = new List<Student>();

    public void AddStudent(Student student)
    {
        students.Add(student);
    }

    public void RemoveStudent(Student student)
    {
        students.Remove(student);
    }

    public void PrintStudents()
    {
        foreach (Student student in students)
        {
            Console.WriteLine($"LastName: {student.LastName}, FirstName: {student.FirstName}, Age: {student.Age}, Major: {student.Major}");
        }
    }

    public Student FindStudent(string lastName, string firstName)
    {
        return students.Find(s => s.LastName == lastName && s.FirstName == firstName);
    }
}

// Main program class
class Program
{
    static void Main(string[] args)
    {
        StudentDatabase database = new StudentDatabase();

        while (true)
        {
            Console.WriteLine("Student Database Menu:");
            Console.WriteLine("1. Add student");
            Console.WriteLine("2. Remove student");
            Console.WriteLine("3. Print students");
            Console.WriteLine("4. Exit");

            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    AddStudent(database);
                    break;
                case 2:
                    RemoveStudent(database);
                    break;
                case 3:
                    database.PrintStudents();
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }

            Console.WriteLine();
        }
    }

    static void AddStudent(StudentDatabase database)
    {
        Console.Write("Enter last name: ");
        string lastName = Console.ReadLine();
        Console.Write("Enter first name: ");
        string firstName = Console.ReadLine();
        Console.Write("Enter age: ");
        int age = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter major: ");
        string major = Console.ReadLine();

        Student student = new Student(lastName, firstName, age, major);
        database.AddStudent(student);
        Console.WriteLine("Student added successfully!");
    }

    static void RemoveStudent(StudentDatabase database)
    {
        Console.Write("Enter last name of the student to remove: ");
        string lastName = Console.ReadLine();
        Console.Write("Enter first name of the student to remove: ");
        string firstName = Console.ReadLine();

        Student studentToRemove = database.FindStudent(lastName, firstName);
        if (studentToRemove != null)
        {
            database.RemoveStudent(studentToRemove);
            Console.WriteLine("Student removed successfully!");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }
}